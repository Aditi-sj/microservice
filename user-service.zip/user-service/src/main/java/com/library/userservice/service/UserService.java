package com.library.userservice.service;

import com.library.userservice.dto.UserDto;
import com.library.userservice.model.User;

public interface UserService {
    public String registerUser(User user);

    public UserDto getUser(int id);
}
