package com.library.userservice.service;

import com.library.userservice.dto.UserDto;
import com.library.userservice.exceptionhandling.UserNotFoundException;
import com.library.userservice.model.User;
import com.library.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.library.userservice.exceptionhandling.UserAlreadyExistsException;

import java.util.logging.Logger;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;
    @Override
    public String registerUser(User user) {
        if (userRepository.existsByUserName(user.getUserName())) {
            throw new UserAlreadyExistsException("User already exists with username: " + user.getUserName());
        }

        userRepository.save(user);
        return "user Registered successfully";


    }

    @Override
    public UserDto getUser(int id) {
        UserDto userDto = new UserDto();
        User user = userRepository.findById(id).orElseThrow(() ->  new UserNotFoundException("user Not foud"+id));
        if(user.getId()==id){

            userDto.setId(user.getId());
            userDto.setName(user.getName());
            userDto.setEmail(user.getEmail());
        }
        return userDto;
    }
}
